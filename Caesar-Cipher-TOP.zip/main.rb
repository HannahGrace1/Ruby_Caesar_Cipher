puts "Type in a word: "
phrase = gets.chomp.downcase

puts "Type in a number that represents how far you want to the shift to be"
number = gets.chomp.to_i

def change(phrase,number)
    alphabet = ('a'..'z').to_a 
    key = Hash[alphabet.zip(alphabet.rotate(number))]
    phrase.each_char.inject("") { |phrasetext, char| phrasetext + key[char] }

end
puts change(phrase,number)



